function hitung(){
let harga = +hargaJual.value;
let modal = +modal.value;
let platform = +platform.value/100;
let feeEvent = +feeEvent.value/100;
let diskon = +diskon.value;
let cashback = +cashback.value;
let voucher = +voucher.value;
let ongkir = +ongkir.value;
let ppn = +ppn.value/100;

let hargaSetelahDiskon = harga - diskon - voucher;
let totalFee = hargaSetelahDiskon * (platform + feeEvent);
let pajak = hargaSetelahDiskon * ppn;

let keuntungan = hargaSetelahDiskon - modal - totalFee - pajak - ongkir + cashback;

hasil.innerHTML = `
<b>Hasil Perhitungan:</b><br>
Harga Setelah Diskon & Voucher: Rp ${hargaSetelahDiskon.toLocaleString()}<br>
Total Fee: Rp ${totalFee.toLocaleString()}<br>
PPN: Rp ${pajak.toLocaleString()}<br>
Keuntungan Bersih: Rp ${keuntungan.toLocaleString()}
`;
}

function hitungHargaJual(){
let modalVal = +modal.value;
let platform = +platform.value/100;
let feeEvent = +feeEvent.value/100;
let ppnVal = +ppn.value/100;
let keuntungan = +keuntunganDiinginkan.value;

let persenTotal = platform + feeEvent + ppnVal;
let harga = (modalVal + keuntungan) / (1 - persenTotal);

hasilHargaJual.innerHTML = `
<b>Harga Jual Disarankan:</b><br>
Rp ${Math.ceil(harga).toLocaleString()}
`;
}
